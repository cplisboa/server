//Importa pacotes para a cria��o de fluxos.
import java.io.*;
//Importa pacotes para a cria��o de sockets.
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.io.BufferedReader;


public class Server {
	
	private ServerSocket server;
	private Socket socket;
	private InputStream entrada;
	private BufferedReader read;
	private static final int PORTA=2020;  
      
	public Server() {
		java.util.Date today;  
		String horario;  
        java.text.DateFormat dateFormatter; 
	    	            
        try {	       
        	//Abre uma porta para escuta (LISTENING)
          	System.out.println("SIGAS GPRS Server. Versao de 25/11/2013.");
          	System.out.println("Vers�o do server GPRS com Threads de tratamento...");
          	System.out.println("Seja bem vindo...");
          	System.out.println("Hora de in�cio: "+Calendar.getInstance().getTime().toString());
		    server = new ServerSocket(PORTA);
	           	            
		    while (true) {
		    	System.out.println("Aguardando nova conex�o, na porta:"+PORTA);	            	
          		socket = server.accept();            		         		
          		
	            System.out.println("Conex�o bem sucedida: " + Calendar.getInstance().getTime().toString());	                	                	                                
	            //Recuperando hora atual
	            long time = System.currentTimeMillis();	            
	            Locale local = new Locale("pt","BR"); 
	                
	            dateFormatter = java.text.DateFormat.getDateInstance(java.text.DateFormat.DEFAULT, local);  
	            today = new java.util.Date(time);  
	            horario = dateFormatter.format(today);
	            SimpleDateFormat formataHora = new SimpleDateFormat("hh:mm");
	            String hora = formataHora.format(today);	                
	            System.out.println("Hor�rio da conex�o e recebimento dos dados.. "+horario+" - "+hora);
	            
	            //Cria um fluxo de entrada
	            try {
	            	entrada = socket.getInputStream();
			        read = new BufferedReader(new InputStreamReader(entrada));
		            	
		            boolean hasData = false;		            	
		            for(int j=0; j<18; j++) {
		            	System.out.println("Verificando dados no socket");
			            if (read.ready()) {
			            	System.out.println("Liberado");
			            	hasData = true;
			            	break;
			            } else {
			            	try{
			            		System.out.println("Vou aguardar 18 x 10 seg para recebimento dos dados");
			            		Thread.sleep(10000);
			            	} catch (Exception e) {
			            		System.out.println("Excess�o aguardando dados no socket");
			            	}
			            }
		            }
		            	
		            if (hasData) {
		            	// Iniciar thread de tratamento
		            	System.out.println("Iniciando nova thread para tratamento");
		            	System.out.println("---------------------------------------------");
		            	ParseData thread = new ParseData(read, socket);
		            	thread.start();
		            }					            
                }catch (Exception e) {
                	System.out.println("Ocorreu um erro durante a interpreta��o dos dados: " + e.getMessage());
                	System.out.println("Reiniciando socket para nova leitura");
                }
            }
	            	            
        //Caso ocorra alguma exe��o na cria��o do fluxo.
        } catch (IOException ex) {
            //Imprimi o que aconteceu de erro
            ex.printStackTrace();
        }        
    }	    
	    
    /**
     * @param args argumentos da linha de comando
     */
    public static void main(String[] args) {
        //Chama o m�todo construtor na classe 
    	new Server();
    }
    
}
