import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;


public class ParseData extends Thread {

	BufferedReader read;
	private Socket socket;	
	private String dadosArquivo = "";
	private String abcissa = "";
	
	private static final String URL_DB = "jdbc:firebirdsql:localhost/3050:C:/juper/old_site/SIGAS.GDB";
	
	/** Construtor que recebe }BufferedReader para tratamento em thread em separado */
	public ParseData (BufferedReader receivedData, Socket serverSocket){
		read = receivedData;
		socket = serverSocket;
	}
	
    public void run() {
    	Database db = null;
        try {
        	System.out.println("Iniciando conex�o com banco de dados");
            db = new Database(URL_DB,"SYSDBA","masterkey");	                	
        }catch (Exception e) {
        	System.out.println("Problema ao conectar na base "+e.getMessage());	                	
        }    	
        String novaData = "";        
        String linha="";
        
        try {
		    System.out.println("Lendo aquele 'A' que n�o serve pra nada...");		            		
			linha = read.readLine();
			System.out.println(linha);		            		
			
		    System.out.println("Lendo coordenadas UTM");		            				            	
			linha = read.readLine();
			System.out.println(linha);		            				            	
			StringTokenizer strToken = new StringTokenizer(linha, ",");
			String setor = strToken.nextToken().trim();
			abcissa = strToken.nextToken().trim();
			String ordenada = strToken.nextToken().trim();
			
		    //Lendo dia e hora
			System.out.println("Lendo data e depois hora..");
		    String date = read.readLine(); //4a linha
		    String hour = read.readLine(); //5a linha
		    System.out.println("> "+date);
		    System.out.println("> "+hour);
		    String horaFormatada = "";
		    Date horaDate = null;
		
			try {
				System.out.println("Parseando data...");
				StringTokenizer strData = new StringTokenizer(date, "/");
					
				String dia = strData.nextToken().trim(); //Pega o dia
			    if (dia.length() == 1)
			    	dia = "0"+dia;
		
				String mes = strData.nextToken().trim(); //Pega o mes
				if (mes.length() == 1)
					mes = "0"+mes;
				String ano = "20" + strData.nextToken().trim(); //Pega o ano		        			        				        			
				novaData = ano + "-" + mes + "-" + dia;   // formato novo '2013-06-15 22:15:00'		        			
				System.out.println("Data formatada: "+novaData);	        			
					
			} catch (Exception e) {  
				System.out.println("Erro parseando data "+e);  
			}		        		
		
			try {
				System.out.println("Parseando hora...");
	            SimpleDateFormat formataHora = new SimpleDateFormat("hh:mm");			
		        horaDate = formataHora.parse(hour);
		        horaFormatada = formataHora.format(horaDate);		                
		        System.out.println("Hora formatada: "+horaFormatada);
					
			} catch (Exception e) {  
				System.out.println("Erro parseando hora "+e);  
			}  	        		
			            	  				
			System.out.println("Come�ando a ler dados que identificam os campos que vir�o...");
			linha=read.readLine();			
		    //Parseando Grandezas
			ArrayList grandezasList = numGrandezas(linha);
						
		    do {
		       	//Parseando linha de dados		    	
		       	linha=read.readLine();		        	
		       	lineData(linha, grandezasList, db, horaDate, novaData);		       	
		    } while(read.ready());
		    System.out.println("Fim do tratamento dos dados. Fechando socket, encerrando a Thread");
		    System.out.println("������������������������������������������������������");
		    read.close();			//Fecha o fluxo de dados
		    socket.close();

        } catch (IOException ex) {
        	System.out.println("Erro lendo dados na parsedata " + ex);
        }
	    	    
	    //Salvando em arquivo
	    saveFile(dadosArquivo);
    }	

    /** Faz o parsing dos valores lidos na linha */
	private void lineData(String linha, ArrayList<Integer> grandezas, Database db, Date horaDate, String novaData){
		ArrayList<String> valueList = new ArrayList<String>();
		
       	System.out.println(linha);
	   	//Parseando
		StringTokenizer str = new StringTokenizer(linha, ",");
		//Primeira dado � sempre o TEMPO
		//TODO isso precisa ser alterado para salvar o numero de grandeza e seu valor.
	   	String tempo = str.nextToken();
	   	String nivel = str.nextToken();
	   	String vazao = str.nextToken();
	   	String corrente = "0";
	       	
	   	//Iterando pelos dados recebidos, a 4a grandeza (iterator=3) � depois de ter lido tempo, nivel e vazao
	   	int iteratorGrandezas = 3;
	   	if (str.hasMoreTokens()) {
	       	do {			            		
	           	String value = str.nextToken();

		   		int gran = grandezas.get(iteratorGrandezas);
		   		if(gran==2) { //2 � o c�digo de corrente
		   		    corrente = value;
		   		    System.out.println("corrente = "+corrente);
		   		} else {
		       		valueList.add(value);
		       		System.out.println("Valor adicionado: "+value);
		   		}
		   		iteratorGrandezas++;
	    	} while (str.hasMoreTokens());
	   	}
	   	
		System.out.println("--------------------------------------------");
	
		int timeToAdd = (int) Float.parseFloat(tempo);
		Calendar cal = Calendar.getInstance();            		
		cal.set(2013, 1, 1, horaDate.getHours(), horaDate.getMinutes());
		//Adicionando tempo entre os steps
		cal.add(Calendar.SECOND, timeToAdd);
	
		//inserindo dados
		try {
			System.out.println("Inserindo na base de dados..");
			insertData(db, 1,novaData,""+cal.get(Calendar.HOUR_OF_DAY),""+cal.get(Calendar.MINUTE),nivel,vazao,corrente, abcissa);		            		
		} catch (Exception e) {
			System.out.println("Erro inserindo no db "+e.getMessage());
			e.printStackTrace();
		}		        			            	
		dadosArquivo+=linha+"\n";
	}
    
private ArrayList<Integer> numGrandezas (String linha){
	System.out.println(linha);
    StringTokenizer str = new StringTokenizer(linha, ",");
    int numGrandeza = 0;
    ArrayList<Integer> list = new ArrayList<Integer>();
    do {			            		
       	String grandeza = str.nextToken();
    	list.add(new Integer(grandeza));
    	System.out.println("Grandeza: "+grandeza);
    	numGrandeza++;
    } while (str.hasMoreTokens());
    System.out.println("Fim das grandezas.. Temos " + numGrandeza + " Grandezas nesse arquivo" );
    
	return list;
}
    
    
public void insertData(Database db, int id, String data, String hora, String minuto, String nivel, String vazao, String corrente, String abcissa) {
	// insert into sigas_pocos values (1, '2013-06-09 22:29:05', 16.21, 10, 0, 110000, 'juper');
	String horaFormatada = "";
	String tsInsert = "";
	
    if (hora.length() == 1)
    	hora = "0" + hora;
    
    if (minuto.length() == 1)
    	minuto = "0" + minuto;
    
    horaFormatada = hora+":"+minuto+":00";
    tsInsert = data+" "+horaFormatada;

	if(db==null)
	    System.out.println("Conex�o com o banco � nula aqui!!!!...");
	String sql = "INSERT INTO sigas_pocos VALUES ("+ id + ", '"+ tsInsert +"', "+nivel+", "+vazao+", "+corrente+", 0,'"+abcissa+"')";
	System.out.println(sql);
	db.insert(sql);
}	    
    
    
//***********************Rotina que  Salva em arquivo *************************/
private void saveFile(String dados){
	try {
		Calendar date = Calendar.getInstance();
		
		  String fileName = null;
		  fileName = date.get(Calendar.DAY_OF_MONTH)+"-"+(date.get(Calendar.MONTH)+1)+"-"+date.get(Calendar.YEAR)+"-";
		  fileName += date.get(Calendar.HOUR)+"."+date.get(Calendar.MINUTE)+"."+date.get(Calendar.SECOND);
		  fileName += "gprs data.csv";			
		FileWriter fis = new FileWriter(fileName);
		BufferedWriter escritor = new BufferedWriter(fis);
		escritor.write(dados);
		escritor.close();
		
		fis.close();
	}catch(Exception e){
		e.printStackTrace();
	}	
}	    

    
}


