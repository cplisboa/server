import java.net.*;
import java.util.Calendar;
/**
 * Classe respons�vel por iniciar as threads de tratamento para os dados enviados pelos Data Loggers.
 * @author Cleo Lisboa
 */
public class Server {
	private ServerSocket server;
	private Socket socket;
	private static final int PORTA=2020;      
	
	public Server(String readFromFile) {
        try {	       
          	System.out.println("SIGAS GPRS Server. Versao FINAL. 1.1 de 01/09/2015.");
          	System.out.println("Calculo de CESP considerando todo o per�odo de bombeamento");
          	System.out.println("Seja bem vindo...");
          	System.out.println("Hora de in�cio: "+Calendar.getInstance().getTime().toString());
          	
		    server = new ServerSocket(PORTA);
		    
		    if(readFromFile!=null) {
		    	System.out.println("MODE DE DEBUG! LENDO DE ARQUIVO: "+readFromFile);
            	ParseData thread = new ParseData(readFromFile);
            	thread.start();      				    			    	
		    } else {
			    while (true) {
			    	System.out.println("Aguardando nova conex�o, na porta:"+PORTA);	            	
	          		socket = server.accept();            		         		

	            	// Iniciar thread de tratamento
	          		System.out.println("Conex�o bem sucedida: " + Calendar.getInstance().getTime().toString());
	            	System.out.println("---------------------------------------------");
	            	ParseData thread = new ParseData(socket);
	            	thread.start();      		
	            }		    	
		    }	           	            
        } catch (Exception ex) {
        	System.out.println("Exception n�o esperada: " + ex.getMessage());
            ex.printStackTrace();
        }        
    }	    
	    
    public static void main(String[] args) {
    	if(args.length > 0)
    		new Server(args[0]);
    	else
    		new Server(null);
    }    
}