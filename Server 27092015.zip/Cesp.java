import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Cesp {

	private Database db;
	private String code;
	private String dataFormatoFirebird;
		
	public Cesp(Database db, String code, Date data) {
		this.db = db;
		this.code = code;
		
		SimpleDateFormat formatData = new SimpleDateFormat("MM-dd-yyyy"); //Formato do firebird
		this.dataFormatoFirebird = formatData.format(data);
		System.out.println("Data no formado do firebird: "+dataFormatoFirebird);		
	}
	
	// vazao / tempo /rebaixamento
	/**
	 * Segundo prof. Lisboa. CESP = vazao media / Rebaixamento
	 * Vazao m�dia = volume bombeado / tempo (em hs)
	 * @param volume
	 * @param dataAtual
	 * @param nivelAtual
	 * @return
	 * @throws Exception
	 */
	public float calculaCesp(float hidrometro, Date dataAtua, Float nivelAtual) throws Exception {
		float cesp = 0; 

		//Recupera medida inicial
		Medida medInicial = getMedidaInicial();		
		
		//Caso medInicial = null, n�o existem dados para o dia
		if (medInicial!= null) {			
			//Calcula diferen�a de tempo entre o in�cio do bombeamento e o tempo atual (em segundos)
			float tempo = diffTempo(dataAtua, medInicial.getDate());
			
			//Calculando o volume bombeado com base no valor do hidrometro na medida inicial
			float volume = hidrometro - medInicial.getHidrometro();
			
			//Tempo em hs
			tempo = tempo / 60 / 60;
			System.out.println("Volume: " + volume);
			System.out.println("Diferen�a de tempo em horas: " + tempo);
			
			//Calculando Vazao M�dia(volume bombeado no per�odo)
			float vazao = volume / tempo;
			System.out.println("Vazao Calcudada: " + vazao);
			
			//Calcula rebaixamento a partir da medida recebida (atual)
			float rebaixamento = getRebaixamento(nivelAtual, medInicial.getNivel());
			System.out.println("Rebaixamento: " + rebaixamento);
			
			cesp = vazao / rebaixamento;
			System.out.println("CESP Calculada: "+cesp+" para o po�o: " + this.code);
		}
		return cesp;
	}
		
	/**
	 * Calcula diferen�a de tempo entre o tempo atual e o in�cio do bombeamento
	 * @param dataAtual
	 * @param dataInicial
	 * @return
	 */
	private float diffTempo(java.util.Date dataAtual, java.util.Date dataInicial){
		float diff = 0;

		//Diferen�a de tempo entre a medida atual e o in�cio do bombeamento.
		Calendar calAtual = Calendar.getInstance();
		calAtual.setTime(dataAtual);
		Calendar calOld = Calendar.getInstance();
		calOld.setTime(dataInicial);
		diff = calAtual.getTimeInMillis() - calOld.getTimeInMillis();
		diff = diff/1000; // Tempo em segundos
		System.out.println("Diferen�a de tempo em segundos: " + diff);
		
		return diff;
	}
	
	/** 
	 * Recupera rebaixamento a partir da base de dados
	 * @return Rebaixamento considerando tempo de inicio de bombeamento e a hora atua
	 */
	private float getRebaixamento(float nivelAtual, float nivelInicial) throws Exception {
		float rebaixamento = 0;
		
		rebaixamento = nivelInicial - nivelAtual;
		System.out.println("Rebaixamento no per�odo: "+rebaixamento);
		if(rebaixamento <0) {
			rebaixamento = 0;
		}		
		return rebaixamento;		
	}
	
	/**
	 * Recupera medida inicial do dia, baseado no fato de haver corrente (bombeamento)
	 * @return Objeto do tipo medida (cont�m hor�rio inicial e n�vel)
	 */
	private Medida getMedidaInicial() throws Exception{
		String SQL_GET_NIVEL_INICIAL = "								" +
				" select FIRST 1 data, nivel, hidrometro from grandezas	" +
				" where code = '"+this.code+"'							" +
				" and data > '"+this.dataFormatoFirebird+"'				" + 
				" and nivel > 0											" +
				" and corrente > 1										" +
				" order by data asc										";
		
		
		Medida med = null;
		System.out.println(SQL_GET_NIVEL_INICIAL);
		ResultSet rs = db.execQuery(SQL_GET_NIVEL_INICIAL);
		if(rs.next()) {
			med = new Medida();
			med.setNivel(rs.getFloat("nivel"));
			med.setDate(rs.getDate("data"));
			med.setHidrometro(rs.getFloat("hidrometro"));
		}
		return med;		
	}

	public static void main(String[] args) {
    	Database db = null;
    	try {
            db = new Database("SYSDBA","masterkey");	                	
        }catch (Exception e) {
        	System.out.println("Problema ao conectar na base "+e.getMessage());	                	
        }    	
    	Date data = Calendar.getInstance().getTime();    	
		Cesp cesp = new Cesp(db,"451707E",data);
		Date dataAgora = Calendar.getInstance().getTime();
		
		try {
			float cespCalculada = cesp.calculaCesp(17000f, dataAgora, 15f);
			System.out.println("CESP Calculada: " + cespCalculada);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}