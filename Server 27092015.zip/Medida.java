import java.util.Date;

public class Medida {

	private float nivel;
	private Date date;
	private float hidrometro;
	
	public Medida() {
		// TODO Auto-generated constructor stub
	}

	public float getNivel() {
		return nivel;
	}

	public void setNivel(float nivel) {
		this.nivel = nivel;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public float getHidrometro() {
		return hidrometro;
	}

	public void setHidrometro(float hidrometro) {
		this.hidrometro = hidrometro;
	}

}
