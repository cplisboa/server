import java.net.*;
import java.util.Calendar;

public class Server {
	private ServerSocket server;
	private Socket socket;
	private static final int PORTA=2020;  
      
	public Server() {	    	            
        try {	       
        	//Abre uma porta para escuta (LISTENING)
          	System.out.println("SIGAS GPRS Server. Versao de 28/10/2014.");
          	System.out.println("GPRS com Threads de tratamento / Recebimento de multiplos pacotes.");
          	System.out.println("Recebimento de dados de vaz�o, volume e corrente em granularidade menor.");
          	System.out.println("Seja bem vindo...");
          	System.out.println("Hora de in�cio: "+Calendar.getInstance().getTime().toString());
		    server = new ServerSocket(PORTA);
	           	            
		    while (true) {
		    	System.out.println("Aguardando nova conex�o, na porta:"+PORTA);	            	
          		socket = server.accept();            		         		

            	// Iniciar thread de tratamento
          		System.out.println("Conex�o bem sucedida: " + Calendar.getInstance().getTime().toString());
            	System.out.println("---------------------------------------------");
            	ParseData thread = new ParseData(socket);
            	thread.start();      		
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }        
    }	    
	    
    public static void main(String[] args) {
    	new Server();
    }    
}