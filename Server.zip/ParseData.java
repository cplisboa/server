import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

public class ParseData extends Thread {

	private String dadosArquivo = "";
	private String abcissa = "";
	private Socket socket;
	private InputStream entrada;
	private BufferedReader read;	
	
	private static final String URL_DB = "jdbc:firebirdsql:localhost/3050:C:/juper/old_site/SIGAS.GDB";
	
	/** Construtor que recebe }BufferedReader para tratamento em thread em separado */
	public ParseData (Socket serverSocket){
		socket = serverSocket;
	}
	
    public void run() {
		java.util.Date today;  
		String horario;  
        java.text.DateFormat dateFormatter; 
    		                	                	                                
        //Recuperando hora atual
        long time = System.currentTimeMillis();	            
        Locale local = new Locale("pt","BR"); 
            
        dateFormatter = java.text.DateFormat.getDateInstance(java.text.DateFormat.DEFAULT, local);  
        today = new java.util.Date(time);  
        horario = dateFormatter.format(today);
        SimpleDateFormat formataHora = new SimpleDateFormat("hh:mm");
        String hora = formataHora.format(today);	                
        System.out.println("Hor�rio da conex�o e recebimento dos dados.. "+horario+" - "+hora);
        
        //Cria um fluxo de entrada
        try {
        	entrada = socket.getInputStream();
	        read = new BufferedReader(new InputStreamReader(entrada));
            	
            boolean hasData = false;		            	
            for(int j=0; j<18; j++) {
            	System.out.println("Verificando dados no socket");
	            if (read.ready()) {
	            	System.out.println("Liberado");
	            	hasData = true;
	            	break;
	            } else {
	            	try{
	            		System.out.println("Vou aguardar 18 x 10 seg para recebimento dos dados");
	            		Thread.sleep(10000);
	            	} catch (Exception e) {
	            		System.out.println("Excess�o aguardando dados no socket");
	            	}
	            }
            }            	
            if (hasData) {
            	receiveData();
            } else {
            	System.out.println("---- Desistindo dessa conex�o, n�o vieram dados. ------");
            }
        }catch (Exception e) {
        	System.out.println("Ocorreu um erro enquanto aguard�vamos os dados: " + e.getMessage());
        }
    }//Fim do m�todo RUN
    
    private void receiveData() {
    	Database db = null;
    	try {
            db = new Database(URL_DB,"SYSDBA","masterkey");	                	
        }catch (Exception e) {
        	System.out.println("Problema ao conectar na base "+e.getMessage());	                	
        }    	
        
        try {
		    System.out.println("Lendo coordenadas UTM");		            				            	
			String linha = read.readLine();
			System.out.println(linha);		            				            	
			StringTokenizer strToken = new StringTokenizer(linha, ",");
			String setor = strToken.nextToken().trim();
			abcissa = strToken.nextToken().trim();
			String ordenada = strToken.nextToken().trim();

			//Lendo intervalo entre medidas
			System.out.println("Lendo intervalo entre medidas e n�mero de medidas em cada pacote ");
			linha = read.readLine();
			System.out.println("> "+linha);
			StringTokenizer strData = new StringTokenizer(linha, ",");
			int tempoEntreMedidas = Integer.parseInt(strData.nextToken().trim()); 
			int numMedidas = Integer.parseInt(strData.nextToken().trim());
			
		    do {
	    		linha=read.readLine();		    		
	    		if (linha.trim().equals("fim")){
	    			System.out.println("Recebido fim do envio de dados. FIM.");
	    			break;
	    		}		    		
		    			    	
			    System.out.println("Come�ando a ler dados que identificam os campos que vir�o...");
				System.out.println("> "+linha);
			    //Parseando Grandezas
				ArrayList grandezasList = numGrandezas(linha);
								
			    //Lendo dia e hora
				System.out.println("Lendo data e depois hora..");
			    String date = read.readLine(); //4a linha
			    String hour = read.readLine(); //5a linha
			    System.out.println("> "+date);
			    System.out.println("> "+hour);
			    String horaFormatada = "";
			    Date horaDate = null;
			    String novaData = "";
			
				try {
					System.out.println("Parseando data...");
					strData = new StringTokenizer(date, "/");
						
					String dia = strData.nextToken().trim(); //Pega o dia
				    if (dia.length() == 1)
				    	dia = "0"+dia;
			
					String mes = strData.nextToken().trim(); //Pega o mes
					if (mes.length() == 1)
						mes = "0"+mes;
					String ano = "20" + strData.nextToken().trim(); //Pega o ano		        			        				        			
					novaData = ano + "-" + mes + "-" + dia;   // formato novo '2013-06-15 22:15:00'		        			
					System.out.println("Data formatada: "+novaData);	        			
						
				} catch (Exception e) {  
					System.out.println("Erro parseando data "+e);  
				}		        		
			
				try {
					System.out.println("Parseando hora...");
					SimpleDateFormat formataHora = new SimpleDateFormat("hh:mm");			
			        horaDate = formataHora.parse(hour);
			        horaFormatada = formataHora.format(horaDate);		                
			        System.out.println("Hora formatada: "+horaFormatada);
						
				} catch (Exception e) {  
					System.out.println("Erro parseando hora "+e);  
				}  	        		
				            	  				
				//System.out.println("Come�ando a ler dados que identificam os campos que vir�o...");
				//linha=read.readLine();			
			    //Parseando Grandezas
				//ArrayList grandezasList = numGrandezas(linha);
					
				//Lendo os dados mais frequentes (pacotes de dados com numMedidas)
				for(int i=0; i<numMedidas; i++) {
					linha=read.readLine();	
					lineData(linha, tempoEntreMedidas, grandezasList, db, horaDate, novaData);
				}
				System.out.println("Terminei de ler os dados de n�vel. Foram: "+numMedidas+ "linhas.");
		    	
		    	
		       	//Parseando linha de dados
		    	System.out.println("Lendo dados menos frequentes...");
	    		
	    		System.out.println("Lendo novas grandezas..");
	    		linha=read.readLine();
	    		System.out.println("> "+linha);
	    		grandezasList = numGrandezas(linha);
	    		
	    		System.out.println("Aqui fazemos o parser dos dados menos frequentes, no momento estamos jogando fora");
	    		linha=read.readLine();
	    		System.out.println("Os dados seriam esses: "+linha);
	    		
		    		
		    	/* else {
		    		try{
	            		System.out.println("Vou aguardar 20 x 10 seg para mais dados");
	            		Thread.sleep(20000);
	            	} catch (Exception e) {
	            		System.out.println("Excess�o aguardando dados no socket");
	            	}		    		
		    	}*/
		    } while(true);
		    System.out.println("Fim do tratamento dos dados. Fechando socket, encerrando a Thread");
		    System.out.println("������������������������������������������������������");
		    read.close();			//Fecha o fluxo de dados
		    socket.close();

        } catch (IOException ex) {
        	System.out.println("Erro lendo dados na parsedata " + ex);
        }
	    	    
	    //Salvando em arquivo
	    saveFile(dadosArquivo);
    	
    }
    
    //private void pacoteDados()

    /** Faz o parsing dos valores lidos na linha */
	private void lineData(String linha, int tempoMedidas, ArrayList<Integer> grandezas, Database db, Date horaDate, String novaData){
		ArrayList<String> valueList = new ArrayList<String>();
		
       	System.out.println(linha);
	   	//Parseando
		StringTokenizer str = new StringTokenizer(linha, ",");
		//Primeira dado � sempre o TEMPO
		//TODO isso precisa ser alterado para salvar o numero de grandeza e seu valor.
	  
	   	String nivel = str.nextToken();
	   	String vazao = "0"; //Fixo em zero at� alterarmos a tabela do banco de dados
	   	String corrente = "0"; //Fixo em zero
	       	
	   	//Iterando pelos dados recebidos, a 4a grandeza (iterator=3) � depois de ter lido tempo, nivel e vazao
	   	int iteratorGrandezas = 3;
	   	if (str.hasMoreTokens()) {
	       	do {			            		
	           	String value = str.nextToken();

		   		int gran = grandezas.get(iteratorGrandezas);
		   		if(gran==2) { //2 � o c�digo de corrente
		   		    corrente = value;
		   		    System.out.println("corrente = "+corrente);
		   		} else {
		       		valueList.add(value);
		       		System.out.println("Valor adicionado: "+value);
		   		}
		   		iteratorGrandezas++;
	    	} while (str.hasMoreTokens());
	   	}
	   	
		System.out.println("--------------------------------------------");
	
		Calendar cal = Calendar.getInstance();            		
		cal.set(2013, 1, 1, horaDate.getHours(), horaDate.getMinutes());
		//Adicionando tempo entre os steps
		cal.add(Calendar.SECOND, tempoMedidas);
	
		//inserindo dados
		try {
			System.out.println("Inserindo na base de dados..");
			insertData(db, 1,novaData,""+cal.get(Calendar.HOUR_OF_DAY),""+cal.get(Calendar.MINUTE),nivel,vazao,corrente, abcissa);		            		
		} catch (Exception e) {
			System.out.println("Erro inserindo no db "+e.getMessage());
			e.printStackTrace();
		}		        			            	
		dadosArquivo+=linha+"\n";
	}
    
private ArrayList<Integer> numGrandezas (String linha){
	System.out.println(linha);
    StringTokenizer str = new StringTokenizer(linha, ",");
    int numGrandeza = 0;
    ArrayList<Integer> list = new ArrayList<Integer>();
    do {			            		
       	String grandeza = str.nextToken();
    	list.add(new Integer(grandeza));
    	System.out.println("Grandeza: "+grandeza);
    	numGrandeza++;
    } while (str.hasMoreTokens());
    System.out.println("Fim das grandezas.. Temos " + numGrandeza + " Grandezas nesse arquivo" );
    
	return list;
}
    
// Inser��o na tabela SIGAS_POCOS    
public void insertData(Database db, int id, String data, String hora, String minuto, String nivel, String vazao, String corrente, String abcissa) {
	// insert into sigas_pocos values (1, '2013-06-09 22:29:05', 16.21, 10, 0, 110000, 'juper');
	String horaFormatada = "";
	String tsInsert = "";
	
    if (hora.length() == 1)
    	hora = "0" + hora;
    
    if (minuto.length() == 1)
    	minuto = "0" + minuto;
    
    horaFormatada = hora+":"+minuto+":00";
    tsInsert = data+" "+horaFormatada;

	if(db==null)
	    System.out.println("Conex�o com o banco � nula aqui!!!!...");
	String sql = "INSERT INTO sigas_pocos VALUES ("+ id + ", '"+ tsInsert +"', "+nivel+", "+vazao+", "+corrente+", 0,'"+abcissa+"')";
	System.out.println(sql);
	db.insert(sql);
}	    
    
	    
	//***********************Rotina que  Salva em arquivo *************************/
	private void saveFile(String dados){
		try {
			Calendar date = Calendar.getInstance();
			
			  String fileName = null;
			  fileName = date.get(Calendar.DAY_OF_MONTH)+"-"+(date.get(Calendar.MONTH)+1)+"-"+date.get(Calendar.YEAR)+"-";
			  fileName += date.get(Calendar.HOUR)+"."+date.get(Calendar.MINUTE)+"."+date.get(Calendar.SECOND);
			  fileName += "gprs data.csv";			
			FileWriter fis = new FileWriter(fileName);
			BufferedWriter escritor = new BufferedWriter(fis);
			escritor.write(dados);
			escritor.close();
			
			fis.close();
		}catch(Exception e){
			e.printStackTrace();
		}	
	}	    
	    
} // Fim da classe ParseData


